<?php
function parseCustomDate($dateStr) {
    $parts = explode(' - ', $dateStr);
    $datePart = trim($parts[0]);
    $dateTimeParts = explode(' ', $datePart);
    $dateOnly = $dateTimeParts[0];
    $timeOnly = (count($dateTimeParts) > 1) ? $dateTimeParts[1] : "00:00";
    $dmy = explode('.', $dateOnly);
    if (count($dmy) != 3) {
        return null;
    }
    list($day, $month, $year) = $dmy;
    if (strlen($year) == 2) {
        $year = "20" . $year;
    }
    $formattedDate = "$year-$month-$day $timeOnly:00";
    return strtotime($formattedDate);
}

$result = [];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['inventoryFile'])) {
    $productsFile = "EWANTO_Produkt.csv"; 
    $products = [];
    

    if (($handle = fopen($productsFile, "r")) !== FALSE) {
        $headerProd = fgetcsv($handle, 1000, ",");
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $sku  = trim($data[0]);
            $type = strtolower(trim($data[1]));
            if ($type !== "set") {
                $products[$sku] = [
                    'count' => 0,
                    'sum'   => 0,
                    'last_entry' => null,
                    'titel' => isset($data[4]) ? trim($data[4]) : "",
                    'hersteller' => isset($data[5]) ? trim($data[5]) : "",
                    'herstellernummer' => isset($data[6]) ? trim($data[6]) : "",
                    'last_update' => isset($data[9]) ? trim($data[9]) : "",
                ];
            }
        }
        fclose($handle);
    } else {
        $error = "Die feste Produktdatei konnte nicht geöffnet werden.";
    }
    

    if (!$error) {
        $inventoryFile = $_FILES['inventoryFile']['tmp_name'];
        $handle = fopen($inventoryFile, "r");
        if (!$handle) {
            $error = "Die Bestandsdatei konnte nicht geöffnet werden.";
        } else {
            $firstLine = fgets($handle);
            rewind($handle);
            
            if (strpos($firstLine, "Zugangsbewegungsmenge") !== false) {
                $tableType = 1;
                $delimiter = (strpos($firstLine, "\t") !== false) ? "\t" : ",";
            } elseif (strpos($firstLine, "Auftragsmenge") !== false) {
                $tableType = 2;
                $delimiter = (strpos($firstLine, ",") !== false) ? "," : "\t";
            } else {
                $error = "Unbekannte Dateistruktur.";
            }
            
            if (!$error) {
                $header = fgetcsv($handle, 1000, $delimiter);
                
                if ($tableType == 1) {
                    $skuIndex  = array_search("Artikelnummer", $header);
                    $qtyIndex  = array_search("Zugangsbewegungsmenge", $header);
                    $dateIndex = array_search("Buchungsdatum", $header);
                } elseif ($tableType == 2) {
                    $skuIndex  = array_search("Artikelnummer", $header);
                    $qtyIndex  = array_search("Auftragsmenge", $header);
                    $dateIndex = array_search("Erstelldatum Wareneingang", $header);
                }
                
                while (($data = fgetcsv($handle, 1000, $delimiter)) !== FALSE) {
                    if (!isset($data[$skuIndex])) continue;
                    $sku = trim($data[$skuIndex]);
                    if ($sku === "") continue;
                    
                    $qtyValue = 0;
                    if (isset($data[$qtyIndex])) {
                        $cleanQty = preg_replace('/[^\d]/', '', $data[$qtyIndex]);
                        $qtyValue = intval($cleanQty);
                    }
                    
                    $dateValue = null;
                    if (isset($data[$dateIndex])) {
                        $dateValue = parseCustomDate($data[$dateIndex]);
                    }
                    
                    
                    if (isset($products[$sku])) {
                        $artikelName = isset($data[2]) ? trim($data[2]) : ""; 
                        $hersteller = strtok($artikelName, ' '); 
                        
                        $products[$sku]['hersteller'] = $hersteller; //  Hersteller
                        
                        if ($qtyValue > 0) {
                            $products[$sku]['count']++;
                            $products[$sku]['sum'] += $qtyValue;
                            if ($dateValue) {
                                if (!$products[$sku]['last_entry'] || $dateValue > $products[$sku]['last_entry']) {
                                    $products[$sku]['last_entry'] = $dateValue;
                                }
                            }
                        }
                    }
                }
                fclose($handle);
                
                $referenceDate = strtotime("2023-11-18");
foreach ($products as $sku => $data) {
    $lastEntryOld = ($data['last_entry'] && $data['last_entry'] < $referenceDate) ? "Ja" : "Nein";
    $lastUpdate = ($data['count'] == 0) ? "Kein Update" : date('Y-m-d', $data['last_entry']);
    $result[] = [
        $sku, 
        $data['count'], 
        $data['sum'], 
        $lastEntryOld,
        $data['hersteller'],
        $data['herstellernummer'],
        $data['titel'],
        $lastUpdate
    ];
}

                
                usort($result, function($a, $b) {
                    return $a[1] <=> $b[1];
                });
                
                // CSV 
                $outputFile = "filtered_results.csv";
                if ($fp = fopen($outputFile, 'w')) {
                    fputcsv($fp, ['SKU', 'Anzahl', 'Summe', 'Letzte Buchung älter als 1 Jahr?', 'Hersteller', 'Herstellernummer', 'Titel', 'Letztes Update']);
                    foreach ($result as $row) {
                        fputcsv($fp, $row);
                    }
                    fclose($fp);
                }
            }
        }
    }
}
?>

<!-- HTML Content for displaying result and upload form -->
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSV Inventar Web-App</title>
    <link rel="stylesheet" href="main.css">
    <style>
        table {
            border-collapse: collapse;
            width: 80%;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #aaa;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Inventar CSV hochladen</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="inventoryFile" required>
            <br><br>
            <button type="submit">Verarbeiten</button>
        </form>
        
        <?php if ($error): ?>
            <p style="color: red;"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        
        <?php if (!empty($result)): ?>
            <h2>Ergebnis</h2>           
            <a href="filtered_results.csv" download>Download CSV</a>
            <table>
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Anzahl</th>
                        <th>Summe</th>
                        <th>Letzte Buchung älter als 1 Jahr?</th>
                        <th>Hersteller</th>
                        <th>Herstellernummer</th>
                        <th>Titel</th>
                        <th>Letztes Update</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($result as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row[0]); ?></td>
                            <td><?php echo htmlspecialchars($row[1]); ?></td>
                            <td><?php echo htmlspecialchars($row[2]); ?></td>
                            <td><?php echo htmlspecialchars($row[3]); ?></td>
                            <td><?php echo htmlspecialchars($row[4]); ?></td>
                            <td><?php echo htmlspecialchars($row[5]); ?></td>
                            <td><?php echo htmlspecialchars($row[6]); ?></td>
                            <td><?php echo htmlspecialchars($row[7]); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <br>

        <?php endif; ?>
    </div>
</body>
</html>  
